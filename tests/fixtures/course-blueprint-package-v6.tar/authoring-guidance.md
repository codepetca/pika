# Authoring guidance

<!-- pika-guidance:v1:pika-0 -->

## Course expectations
<!-- pika-guidance:pika-0:begin:course_expectations_markdown -->
Use clear success criteria for each unit.
<!-- pika-guidance:pika-0:end:course_expectations_markdown -->

## Assignment guidance
<!-- pika-guidance:pika-0:begin:assignment_guidance_markdown -->
Offer a choice of formats where feasible.
<!-- pika-guidance:pika-0:end:assignment_guidance_markdown -->

## Test guidance
<!-- pika-guidance:pika-0:begin:test_guidance_markdown -->
Include a short reflection after each test.
<!-- pika-guidance:pika-0:end:test_guidance_markdown -->

## Unit: Unit 1: Foundations
<!-- pika-guidance:pika-0:unit:%7B%22id%22%3A%2281000000-0000-4000-8000-000000000006%22%2C%22unit_label%22%3A%22Unit%201%3A%20Foundations%22%7D -->

### Assignment guidance
<!-- pika-guidance:pika-0:begin:assignment_guidance_markdown -->
Let students cite a worked example.
<!-- pika-guidance:pika-0:end:assignment_guidance_markdown -->

### Test guidance
<!-- pika-guidance:pika-0:begin:test_guidance_markdown -->
Check vocabulary before reasoning questions.
<!-- pika-guidance:pika-0:end:test_guidance_markdown -->

<!-- pika-guidance:pika-0:end -->