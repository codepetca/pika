# Test
Title: Legacy Foundations Test
Show Results: true

## Questions
### Question 1
Type: open_response
Points: 3
Prompt:
Explain the legacy package boundary.
Answer Key:
Reusable Test content remains supported.

## Documents
### Document 1
Source: link
Title: Legacy Reference
URL: https://example.com/legacy-reference