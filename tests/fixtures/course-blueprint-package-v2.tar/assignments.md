## Legacy Reflection [DRAFT]
Due Days: 2
Due Time: 16:45
Points: 8

Explain one reusable idea from this course.

---