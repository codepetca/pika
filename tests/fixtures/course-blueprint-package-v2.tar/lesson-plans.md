## Legacy Course Launch

Review the course structure and expectations.

---