## Version 3 Reflection [DRAFT]
Due Days: 4
Due Time: 15:30
Points: 12
Gradebook Weight: 10
Include In Final: true

Compare two course concepts.

---