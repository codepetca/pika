## Version 3 Lesson

Teach the version 3 compatibility boundary.

---