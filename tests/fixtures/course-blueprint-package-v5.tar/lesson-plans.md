## Version 5 Lesson
Artifact ID: 61000000-0000-4000-8000-000000000005

Teach immutable Version lineage.

---