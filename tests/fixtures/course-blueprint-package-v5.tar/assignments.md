## Version 5 Project [DRAFT]
Artifact ID: 41000000-0000-4000-8000-000000000005
Classwork Position: 0
Due Days: 8
Due Time: 13:45
Points: 35
Gradebook Weight: 19
Include In Final: true
Track Authenticity: true

Build a portable course artifact.

### Submission Requirements
- 42000000-0000-4000-8000-000000000005 | link | Project link | required | Submit the published artifact.

---