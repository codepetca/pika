# Test
Title: Version 5 Unit Test
Artifact ID: 51000000-0000-4000-8000-000000000005
Points Possible: 40
Gradebook Weight: 29
Include In Final: true
Show Results: false

## Questions
### Question 1
ID: 52000000-0000-4000-8000-000000000005
Type: open_response
Points: 6
Code: false
Max Chars: 900
Prompt:
Describe stable Artifact ID lineage.
Answer Key:
The identity survives packages, Versions, and classrooms.

## Documents
### Document 1
ID: 53000000-0000-4000-8000-000000000005
Source: link
Title: Version 5 Reference
URL: https://example.com/version-5-reference

### Document 2
ID: 54000000-0000-4000-8000-000000000005
Source: text
Title: Version 5 Notes
Content:
Portable text content remains embedded.