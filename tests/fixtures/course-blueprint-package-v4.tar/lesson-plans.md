## Version 4 Lesson

Teach strict post-Quiz package boundaries.

---