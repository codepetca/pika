# Test
Title: Version 4 Unit Test
Show Results: true
Points Possible: 25
Gradebook Weight: 23
Include In Final: false

## Questions
### Question 1
Type: open_response
Points: 5
Code: true
Max Chars: 1200
Prompt:
Explain why undeclared files fail closed.
Answer Key:
Version 4 has a strict file contract.

## Documents
### Document 1
Source: text
Title: Version 4 Notes
Content:
Portable text document content.