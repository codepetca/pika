## Version 4 Investigation [DRAFT]
Due Days: 6
Due Time: 14:15
Points: 20
Gradebook Weight: 17
Include In Final: false
Track Authenticity: true

Investigate the retired Quiz boundary.

---